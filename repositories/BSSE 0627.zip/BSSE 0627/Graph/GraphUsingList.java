package Assignment.one;
/*
  * Arguments
8
0 1 0 0 0 0 0 0
1 0 1 0 0 0 0 0
0 1 0 1 0 0 0 0
0 0 1 0 1 1 0 0
0 0 0 1 0 1 1 0
0 0 0 1 1 0 0 1
0 0 0 0 1 0 0 1
0 0 0 0 0 1 1 0
*/
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class GraphUsingList {
	public static void main(String[] args)throws IOException {
		
		List <Vertex> vertices= new ArrayList<>();
		
		int argCounter=0;
		int noOfVertex=Integer.parseInt(args[argCounter]);
		System.out.println("No. of Vertices: "+noOfVertex);
		argCounter++;
		for(int i=0; i<noOfVertex; i++)
		{
			Vertex v=new Vertex(i);
			vertices.add(v);
		}
	
		for(int i=0; i<noOfVertex; i++)
		{	
			for( int j=0; j<noOfVertex; j++)
			{	
				int temp=Integer.parseInt(args[argCounter]);
				
				if(temp==1)
				{	
					vertices.get(i).neighbours.add(vertices.get(j));
				}
				
				argCounter++;
			}			
		}
		
	//	vertices.get(2).removeEdge(vertices.get(2), vertices.get(1));
		
		System.out.println("Vertices Edges");	
		for(int i=0; i< vertices.size(); i++)
			//System.out.print(vertices.get(k).vertexName+" ");
			System.out.println(vertices.get(i));
		
		
	}
}
