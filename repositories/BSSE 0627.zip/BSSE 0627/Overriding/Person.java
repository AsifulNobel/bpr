package Overriding;


public class Person  {
	String Name;
	int Age;
	String Gender;
	public Person(String name, int age, String gender) {
		// TODO Auto-generated constructor stub
		Name= name;
		Age= age;
		Gender= gender;
	}
	
	
	
	@Override
	public boolean equals(Object person) {
		// TODO Auto-generated method stub
		if(this==person) return true;
		if(this.getClass()!=person.getClass()) return false;
		
		Person p1=(Person) person;
	
		if((this.Name.compareTo(p1.Name))!=0)
				return false;
			
		if(this.Age!=p1.Age)
				return false;
			
		return this.Gender.equals(p1.Gender);
		}

		
	}

