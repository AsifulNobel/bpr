package Overriding;

public class mainOverride {
	public static void main(String[] args) {
		Person person1= new Person("Muna", 20, "Female");
		Person person2= new Person("Mumu", 21, "Female");
		Person person3= new Person("Muna", 20, "Female");
		Person person4= new Person("Tawsif", 19, "Male");
		
		System.out.println(" "+person1.Name+" vs "+person2.Name+": "+person1.equals(person2));
		System.out.println(" "+person1.Name+" vs "+person3.Name+": "+person1.equals(person3));
		System.out.println(" "+person2.Name+" vs "+person4.Name+": "+person2.equals(person4));
	}
}
